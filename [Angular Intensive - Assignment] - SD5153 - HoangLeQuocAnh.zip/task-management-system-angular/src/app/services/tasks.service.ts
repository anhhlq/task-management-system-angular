import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Task } from '../models/task';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TasksService {
  private apiUrl = "http://localhost:3000/tasks";

  constructor(private httpClient: HttpClient) { }

  createTask(task: Task) : Observable<Task> {
    return this.httpClient.post<Task>(this.apiUrl, task);
  }

  getTasks() : Observable<Task[]> {
    return this.httpClient.get<Task[]>(this.apiUrl);
  }

  getTaskById(id: string) {
    const url = `${this.apiUrl}/${id}`
    return this.httpClient.get<Task>(url);
  }

  updateTask(task: Task) : Observable<Task> {
    const url = `${this.apiUrl}/${task.id}`
    return this.httpClient.put<Task>(url, task);
  }

  deleteTask(id: string): Observable<void>  {
    const url = `${this.apiUrl}/${id}`;
    return this.httpClient.delete<void>(url);
  }
}
