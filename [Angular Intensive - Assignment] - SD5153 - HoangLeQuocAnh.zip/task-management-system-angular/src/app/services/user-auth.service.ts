import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
  private apiUrl = "http://localhost:3000/users";
  constructor(private httpClient: HttpClient) { }

  login(email: string, password: string) : Observable<User> {
    const url = `${this.apiUrl}?email=${email}&password=${password}`
    return this.httpClient.get<User>(url); 
  }

  logout() {
    if(localStorage.getItem('token') != "" && localStorage.getItem('token') != null){
      localStorage.removeItem('token');
      ;
    }
  }
}
