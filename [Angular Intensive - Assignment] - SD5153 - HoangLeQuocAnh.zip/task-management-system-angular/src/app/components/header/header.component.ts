import { Component } from '@angular/core';
import { UserAuthService } from '../../services/user-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  title = 'TMS';
  public isAuthenticated = false;

  ngOnInit(): void {
    if(localStorage.getItem('token') != "" && localStorage.getItem('token') != null){
      this.isAuthenticated = true;
    }
  }

  constructor(private userAuthService: UserAuthService, private router: Router) {}
  
  public logout(): void {
    this.userAuthService.logout();
    this.isAuthenticated = false;
    this.router.navigateByUrl('/login');
  }
}
