import { Component, OnInit } from '@angular/core';
import { UserAuthService } from '../../services/user-auth.service';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  email:string = "";
  password:string = "";
  isSubmitting:boolean = false;
  public loginValid = true;

  constructor(private userAuthService: UserAuthService, private router: Router) {}
  
  ngOnInit(): void {
    if(localStorage.getItem('token') != "" && localStorage.getItem('token') != null) {
      this.router.navigateByUrl('/home')
    }
  }

  loginAction() {
    this.isSubmitting = true;
    this.userAuthService.login(this.email, this.password).subscribe((data: User) => {
      if (Object.keys(data).length != 0) {
        localStorage.setItem('token', JSON.stringify(data));
        this.router.navigate(['home']);
      } else {
        this.loginValid = false;
      }
    });
  }
}
