export interface User {
    id: number;
    name: string;
    role: string;
    password: string;
    email: string;
    token: string;
}
