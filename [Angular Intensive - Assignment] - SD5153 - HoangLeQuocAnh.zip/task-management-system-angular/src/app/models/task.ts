export interface Task {
    id: string | any;
    taskId: string;
    title: string;
    description: string;
    status: string;
    priority: string;
    assignee: string;
    startDate: Date | any;
    endDate: Date | any;
    createdDate: Date;
    updatedDate: Date;
    createdBy: string;
    updatedBy: string;
}
