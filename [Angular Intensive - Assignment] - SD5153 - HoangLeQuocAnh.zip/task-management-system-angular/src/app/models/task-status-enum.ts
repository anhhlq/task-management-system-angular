export enum TaskStatus {
    OPEN,
    ONHOLD,
    PENDING,
    IMPLEMENTATION,
    INTEGRATION,
    CLOSED
}