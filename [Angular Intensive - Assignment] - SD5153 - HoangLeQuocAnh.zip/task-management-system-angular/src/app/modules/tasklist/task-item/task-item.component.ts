import { Component } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Task } from 'src/app/models/task';
import { TasksService } from 'src/app/services/tasks.service';

@Component({
  selector: 'app-task-item',
  templateUrl: './task-item.component.html',
  styleUrls: ['./task-item.component.scss']
})
export class TaskItemComponent {
  taskItem!: Task;
  taskUuid!: string;
  
  constructor(private tasksService: TasksService, private route: ActivatedRoute) {
    this.taskUuid = this.route.snapshot.paramMap.get("id") ||  '';
    this.tasksService.getTaskById(this.taskUuid).subscribe((data: Task) => {
      this.taskItem = data;
    });
  }
}
