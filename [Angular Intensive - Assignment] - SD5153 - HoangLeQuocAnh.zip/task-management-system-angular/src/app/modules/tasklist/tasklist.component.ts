import { Component, ViewChild } from '@angular/core';
import { Task } from '../../models/task';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';

import { TasksService } from '../../services/tasks.service';
import { ConfirmDialogComponent } from 'src/app/components/confirm-dialog/confirm-dialog.component';
import { Router } from '@angular/router';
import { TaskStatus } from 'src/app/models/task-status-enum';
import { FormControl } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';

@Component({
  selector: 'app-tasklist',
  templateUrl: './tasklist.component.html',
  styleUrls: ['./tasklist.component.scss']
})
export class TasklistComponent {
  
  tasks: Task[] = [];
  taskStatusList = Object.getOwnPropertyNames(TaskStatus).filter( prop => isNaN(parseInt(prop)));
  taskStatuses = new FormControl('');
  searchText!: string;
  selectedValues: string[] = [];

  constructor(private tasksService: TasksService, private dialog: MatDialog, private route: Router) {
    this.loadTasks();
    if(!(localStorage.getItem('token') != "" && localStorage.getItem('token') != null)){
      route.navigate(['login']);
    }
  }

  dataSource = new MatTableDataSource(this.tasks);
  displayColumns = ["taskId", "title","description", "status", "priority", "assignee", "startDate", "endDate", "actions"];
  selection = new SelectionModel(true, []);

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  selectHandler(row: Task) {
    this.selection.toggle(row as never);
  }

  loadTasks() {
    this.tasksService.getTasks().subscribe((data: Task[]) => {
      this.tasks = data;
      this.dataSource = new MatTableDataSource(this.tasks);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  deleteTask(task: Task) {
    const confirmDialog = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Confirm Remove Task',
        message: 'Are you sure, you want to remove task: ' + task.taskId
      }
    });
    confirmDialog.afterClosed().subscribe(result => {
      if (result === true) {
        this.tasksService.deleteTask(task.id).subscribe((data) => {
          this.loadTasks();
        })
      }
    });
  }

  addNewRask() {
    this.route.navigateByUrl("/tasks/add");
  }

  onSearchKeyUp(text: string) {
    if (text != '') {
      this.dataSource.filter = text;
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }
  }

  onStatusFilterChange(event: MatSelectChange) {
    this.selectedValues = event.value
    this.dataSource.filter = this.selectedValues[0] || this.selectedValues[1] || this.selectedValues[2] || this.selectedValues[3] || this.selectedValues[4] || this.selectedValues[5];
  }
  // customFilterPredicate(): (data: Task, filter: string) => boolean {
  //   const filterFunction = (data: Task, filter: string) : boolean => {
  //     console.log("aaaaa")
  //     return data.status.includes(filter)
  //   }
  //   return filterFunction;
  // }
}
