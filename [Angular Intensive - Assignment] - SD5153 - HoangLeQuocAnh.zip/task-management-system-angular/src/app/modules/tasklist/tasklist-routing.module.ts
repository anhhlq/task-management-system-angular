import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TasklistComponent } from './tasklist.component';
import { TaskItemComponent } from './task-item/task-item.component';
import { PageNotFoundComponent } from 'src/app/page-not-found/page-not-found.component';
import { TaskFormComponent } from './task-form/task-form.component';

const routes: Routes = [
  { path: '', component: TasklistComponent },
  { path: 'add', component: TaskFormComponent },
  { path: 'view/:id', component: TaskItemComponent },
  { path: 'edit/:id', component: TaskFormComponent },
  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TasklistRoutingModule { }
