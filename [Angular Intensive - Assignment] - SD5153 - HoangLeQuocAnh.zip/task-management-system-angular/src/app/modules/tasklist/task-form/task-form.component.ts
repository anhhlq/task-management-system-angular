import { Component } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Task } from 'src/app/models/task';
import { TasksService } from 'src/app/services/tasks.service';
import {v4 as uuidv4} from 'uuid'

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.scss']
})
export class TaskFormComponent {

  taskUuid!: string;
  formAction: string = "create";

  taskData: Task = {
    id: uuidv4(),
    taskId: `APP-${ Math.floor(1000 + Math.random() * 9000)}`,
    title: "",
    description: "",
    status: "OPEN",
    priority: "low",
    assignee: "Unassign",
    startDate: undefined,
    endDate: undefined,
    createdDate: new Date(),
    updatedDate: new Date(),
    createdBy: "",
    updatedBy: ""
  }

  constructor(private tasksService: TasksService, private router: Router,  private route: ActivatedRoute) {
    this.taskUuid = this.route.snapshot.paramMap.get("id") || '';
    if (this.taskUuid != '') {
      this.formAction = 'edit';
      this.tasksService.getTaskById(this.taskUuid).subscribe((data: Task) => {
        this.taskData = data;
      });
    }
  }
  saveTask() {
    // EDIT
    if (this.formAction = 'edit') {
      alert("edit");
    } else {
      this.tasksService.createTask(this.taskData).subscribe((data) => {
        this.router.navigate(['tasks']);
      });
    }
  }
}
